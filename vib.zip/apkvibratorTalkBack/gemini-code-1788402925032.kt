package com.example.vibrationtester

import android.content.Context
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.accessibility.AccessibilityManager
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.*
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    private lateinit var vibrator: Vibrator
    private var vibrationJob: Job? = null
    private val coroutineScope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Vibrator inicializáció Android verzió szerint
        vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
            vibratorManager.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }

        val btnConsistent = findViewById<Button>(R.btnConsistent)
        val btnPulsing = findViewById<Button>(R.btnPulsing)
        val btnUnpredictable = findViewById<Button>(R.btnUnpredictable)
        val btnStop = findViewById<Button>(R.btnStop)

        btnConsistent.setOnClickListener {
            startConsistentMode()
            announceForAccessibility("Állandó rezgés mód elindítva")
        }

        btnPulsing.setOnClickListener {
            startPulsingMode()
            announceForAccessibility("Pulzáló rezgés mód elindítva")
        }

btnUnpredictable.setOnClickListener {
            startUnpredictableMode()
            announceForAccessibility("Kiszámíthatatlan rezgés mód elindítva")
        }

        btnStop.setOnClickListener {
            stopVibration()
            announceForAccessibility("Rezgések leállítva")
        }
    }

    // 1. Consistent Mode: Folyamatos, szünetmentes rezgés
    private fun startConsistentMode() {
        stopVibration()
        vibrationJob = coroutineScope.launch {
            while (isActive) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(VibrationEffect.createOneShot(2000, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(2000)
                }
                delay(1900) // Minimális átfedés a folyamatos hatásért szünet nélkül
            }
        }
    }

    // 2. Pulsing Mode: Szabályos időközönként ismétlődő impulzusok
    private fun startPulsingMode() {
        stopVibration()
        vibrationJob = coroutineScope.launch {
            while (isActive) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(VibrationEffect.createOneShot(400, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(400)
                }
                delay(800) // Szabályos szünet a pulzusok között
            }
        }
    }

    // 3. Unpredictable Mode: Véletlenszerű időtartamok és szünetek
    private fun startUnpredictableMode() {
        stopVibration()
        vibrationJob = coroutineScope.launch {
            while (isActive) {
                val randomDuration = Random.nextLong(100, 1000)
                val randomDelay = Random.nextLong(200, 1500)

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(VibrationEffect.createOneShot(randomDuration, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(randomDuration)
                }
                delay(randomDuration + randomDelay)
            }
        }
    }

    private fun stopVibration() {
        vibrationJob?.cancel()
        vibrator.cancel()
    }

    private fun announceForAccessibility(text: String) {
        val accessibilityManager = getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        if (accessibilityManager.isEnabled) {
            window.decorView.announceForAccessibility(text)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        stopVibration()
        coroutineScope.cancel()
    }
}