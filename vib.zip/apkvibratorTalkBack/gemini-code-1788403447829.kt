// 4. Sucking / Vacuum Mode imitáció
private fun startVacuumMode() {
    stopVibration()
    vibrationJob = coroutineScope.launch {
        while (isActive) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                // Lépésről lépésre erősödő rezgés (felfutás)
                for (amplitude in 50..255 step 51) {
                    vibrator.vibrate(VibrationEffect.createOneShot(40, amplitude))
                    delay(40)
                }
                // Hirtelen üresség / leállás, ami a "beszívás" érzetet kelti
                vibrator.cancel()
                delay(600) // Szünet a következő "beszívás" előtt
            }
        }
    }
}